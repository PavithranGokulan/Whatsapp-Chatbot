import pyautogui as p
import pyperclip as pc
from pynput.mouse import Button, Controller
from time import sleep

p.FAILSAFE=True
mouse=Controller()

def nav_image(image,clicks,off_x=0,off_y=0):
    position=p.locateCenterOnScreen(image,confidence=.8)
    if position is None:
        #print(f'{image}not found...!')
        return 0
    else:
        p.moveTo(position,duration=.5)
        p.moveRel(off_x,off_y,duration=.2)
        p.click(clicks=clicks, interval=.1)

def get_msg():
    nav_image('pyperclip2.png',0,off_y=-65)
    mouse.click(Button.left,3)
    p.rightClick()

    copy=nav_image('copy.png',1)
    sleep(.5)
    return pc.paste() if copy!=0 else 0

def send_message(msg):
    nav_image('pyperclip2.png',2,off_x=100)
    p.typewrite(msg,interval=0.05)
    p.typewrite('\n')

def close_reply_box():
    nav_image('x2.png',2)

def process_message(msg):
    new_msg=msg.lower()
    if new_msg in "hiii":
        return "Hii Bro/Sis...! I am your Chatbot...! If you have any Queries related to SPACE Text me I will be replying you in seconds"
    elif new_msg in 'which is the smallest planet in our solar system?':
        return " Answer for your Question is: Mercury"
    elif new_msg in "which is the second smallest planet with in our solar system?":
        return " Answer for your Question is: Mars"
    elif new_msg in "the moon called Titan orbits which planet?":
        return " Answer for your Question is: Saturn"
    elif new_msg in "which is the brightest planet in the night sky":
        return " Answer for your Question is: Venus"
    elif new_msg in "which planet is larger, Neptune or Saturn?":
        return " Answer for your Question is: Saturn"
    elif new_msg in "Uranus has only been visited by what spacecraft?":
        return " Answer for your Question is: the Voyager 2"
    elif new_msg in "there have been more missions to this planet versus any other planet":
        return " Answer for your Question is: Mars"
    elif new_msg in "what protects Earth from meteoroids and radiation from the sun?":
        return " Answer for your Question is: It’s atmosphere"
    elif new_msg in "how many of our planets can be seen without a telescope?":
        return " Answer for your Question is: 5—Mercury, Venus, Mars, Jupiter, and Saturn"
    elif new_msg in "Phobos and Deimos are the Moons of which planet?":
        return " Answer for your Question is: Mars" 
    elif new_msg in "which planet is closest in size to earth?":
        return " Answer for your Question is: Venus"
    elif new_msg in "which planet has the most moons?":
        return " Answer for your Question is: Saturn"
    elif new_msg in "which planet have no moons?":
        return " Answer for your Question is: Mercury and Venus"
    elif new_msg in "which planet has supersonic winds?":
        return " Answer for your Question is: Neptune"
    elif new_msg in "which planet has the fastest rotation?":
        return " Answer for your Question is: Jupiter"
    elif new_msg in "how long is one year on Jupiter?":
        return " Answer for your Question is: 12 Earth years"
    elif new_msg in "which is the oldest planet in our solar system?":
        return " Answer for your Question is: Jupiter"
    elif new_msg in "which is the densest planet in our solar system?":
        return " Answer for your Question is: Earth"
    elif new_msg in "which planet is known as the morning star?":
        return " Answer for your Question is: Venus"
    elif new_msg in "which planet is known as the evening star?":
        return " Answer for your Question is: Venus"
    elif new_msg in "which planets haverings around them?":
        return " Answer for your Question is: Jupiter, Saturn, Uranus, and Neptun"
    elif new_msg in "which planet has the most volcanoes?":
        return " Answer for your Question is: Venus"
    elif new_msg in "what are the names of Jupiter’s four largest moons?":
        return " Answer for your Question is: Europa, Ganymede, Callisto,Europa, Ganymede, Callisto,"
    elif new_msg in "which planet spins backward relative to the others?":
        return " Answer for your Question is: Venus"
    elif new_msg in "which are the four gas giant planets?":
        return " Answer for your Question is: Jupiter, Saturn, Uranus, and Neptune"
    elif new_msg in "which are the five most recognized dwarf planets?":
        return " Answer for your Question is: Pluto, Ceres, Eris, Makemake, and haumea"
    elif new_msg in "in what year did Pluto become reclassified as a dwarf planet?":
        return " Answer for your Question is: 2006"
    elif new_msg in "which planet rotates on its side?":
        return " Answer for your Question is: Uranus"
    elif new_msg in "which are the four terrestrial planets":
        return " Answer for your Question is: Mercury, Venus, Mars, and Earth"
    elif new_msg in "how many moons does Earth have?":
        return " Answer for your Question is: Just one!"
    elif new_msg in "what causes a solar eclipse?":
        return " Answer for your Question is: the moon moves between the sun and Earth, cast in g a shadow on Earth"
    elif new_msg in "where can the biosphere be found?":
        return " Answer for your Question is: the lower part of the atmosphere, all of the hydrosphere, and the upper part of the lithosphere"
    elif new_msg in "where is the Oort Cloud located?":
        return "Answer for your Question is: Just beyond Pluto"
    elif new_msg in "what phenomena keeps the planets  in  steady orbit around the sun?":
        return " Answer for your Question is: Gravity"
    elif new_msg in "which is the largest start with in our solar system?":
        return " Answer for your Question is: the sun"
    elif new_msg in "why does Mercury have craters?":
        return " Answer for your Question is: Its atmosphere is too th in  to burn up meteoroid"
    elif new_msg in "which star is the center of our solar system?":
        return " Answer for your Question is: the sun"
    elif new_msg in "how old is the sun?":
        return " Answer for your Question is: Roughly 4.6 billion years old"
    elif new_msg in "how long does it take the sun’s rays to reach Earth?":
        return " Answer for your Question is: Eight minutes"
    elif new_msg in "when did the solar system form?":
        return " Answer for your Question is: 4.6 billion years ago"
    elif new_msg in "who was the first person to walk on the moon?":
        return " Answer for your Question is: Neil Armstrong"
    elif new_msg in "who was the first person to travel in to space?":
        return " Answer for your Question is: Yuri Gagar in "
    elif new_msg in "who was the first woman to travel in to space?":
        return " Answer for your Question is: Valent in a Tereshkova"
    elif new_msg in "Asteroids are also referred to as what?":
        return " Answer for your Question is: Minor planets or planetoids"
    elif new_msg in "Name the three most famous asteroids":
        return " Answer for your Question is: Ceres, Pallas, Vesta"
    elif new_msg in "what do you call a large number of meteoroids occurr in g at the same time and place?":
        return " Answer for your Question is: A meteor shower"
    elif new_msg in "what color is the sun?":
        return " Answer for your Question is: the sun appears white to the eye, but it is a mixture of all colors"
    elif new_msg in "what elements is the sun composed of?":
        return " Answer for your Question is: Primarily hydrogen and helium, with some other trace elements"
    elif new_msg in "how many Earths could fit  in side the sun?":
        return " Answer for your Question is: One million"
    elif new_msg in "what are the explosions of energy released by the sun’s magnetic fields called?":
        return " Answer for your Question is: Solar flares"
    elif new_msg in "why isn’t it possible to walk on Jupiter, Saturn, Uranus, or Neptune?":
        return " Answer for your Question is: Because they do not have solid surfaces"
    elif new_msg in "what color is Mars’ sunset?":
        return " Answer for your Question is: Blue"
    elif new_msg in "what do you call a large group of stars, dust, and gas?":
        return " Answer for your Question is: A galaxy"
    elif new_msg in "who was the third astronaut to walk on the moon?":
        return " Answer for your Question is: Pete Conrad"
    elif new_msg in "what does NASA stand for?":
        return " Answer for your Question is: National Aeronautics and Space Adm in istration"
    elif new_msg in "what are the largest stars  in  the universe?":
        return " Answer for your Question is: Red Giant stars"
    elif new_msg in "how many moons are currently  in  our solar system?":
        return " Answer for your Question is: 181 moons"
    elif new_msg in "what is the name of our galaxy?":
        return " Answer for your Question is: the milky way"
    elif new_msg in "what planet is closest to the sun?":
        return " Answer for your Question is: Mercury"
    elif new_msg in "which is the hottest planet?":
        return " Answer for your Question is: Venus"
    elif new_msg in "what is the Earth’s biggest satellite?":
        return " Answer for your Question is: the moon"
    elif new_msg in ": which is the smallest planet?":
        return " Answer for your Question is: Mercury"
    elif new_msg in "how long does it take Earth to orbit around the sun?":
        return " Answer for your Question is: 365 day"
    elif new_msg in "how long does it take the Earth to rotate/sp in  all the wayaround?":
        return " Answer for your Question is: 24 hours"
    elif new_msg in "what is a blue moon?":
        return " Answer for your Question is: the second full moon  in  a month"
    elif new_msg in "how long does it take the moon to orbit the Earth?":
        return " Answer for your Question is: 29 days"
    elif new_msg in "which planet is nicknamed the red planet?":
        return " Answer for your Question is: mars"
    elif new_msg in "what is the name of the 2nd biggest planet  in  our solar system?":
        return "  Answer for your Question is: Saturn"
    elif new_msg in "what is the name of the largest ocean on earth?":
        return " Answer for your Question is: the Pacific Ocean"
    elif new_msg in "which planet is sometimes called earth's sister planet?":
        return " Answer for your Question is: venus"
    elif new_msg in "how long is one day on Venus compared to Earth days?":
        return "  Answer for your Question is: 1 day on Venus is the same as 365 days (1 year) on Earth."
    elif new_msg in "how many planets are there in our Solar System?":
        return "  Answer for your Question is: 8"
    elif new_msg in "why do we have a leap year every four years? ":
        return " Answer for your Question is: the extra 0.25 is added up over four years and adds a day to the end of February every four years. "
    elif new_msg in "how long does it take the Moon to orbit the Earth?":
        return " Answer for your Question is: 27 days"
    elif new_msg in "the planet having no moon is?":
        return " Answer for your Question is: Mercury"
    elif new_msg in "the distance of the nearest star besides the sun from the earth is":
        return " Answer for your Question is: 4 light years"
    elif new_msg in " which of the following part of the Sun is visible to humans?":
        return " Answer for your Question is: Photosphere"
    elif new_msg in " which of the following is the largest planet of the Solar System according to size?":
        return " Answer for your Question is: Jupiter"
    elif new_msg in "which of the following planets  in  the Solar System takes the shortest revolution?":
        return " Answer for your Question is: Mercury"
    elif new_msg in "which planet in the Solar System has the highest density?":
        return " Answer for your Question is: Earth"
    elif new_msg in "Name  in dia's first satellite and when it was launched?":
        return " Answer for your Question is: Aryabhatta, 19 April 1975"
    elif new_msg in "which satellite is known as Earth observation satellite that was launched on 5 May 2005?":
        return " Answer for your Question is: CARTOSAT-1"
    elif new_msg in "thanks":
        return "You are Always Welcome...!"
    else:
        return "Sorry Bro/Sis I am unable to understand your Question or I may not have answer for your Question..."
    
lst_msg=''
sleep(5)
while True:
    nav_image('greendot2.png',2,off_x=-100)
    close_reply_box()
    msg=get_msg()
    if msg!=0 and msg!=lst_msg:
        lst_msg=msg
        send_message(process_message(msg))
    else:
        print('No new messages...!')
    sleep(3)
